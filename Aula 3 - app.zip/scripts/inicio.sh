#!/bin/bash
if [ -f /var/www/html/teste.php ]; then
   sudo rm /var/www/html/teste.php
fi