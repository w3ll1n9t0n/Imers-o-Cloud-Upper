#!/bin/bash
cd /home/ubuntu/
sudo cp style.css /var/www/html/cache/themes/SuiteP/css/Dawn/
sudo cp teste.php /var/www/html/
sudo chown www-data:www-data /var/www/html/teste.php
sudo chown www-data:www-data /var/www/html/cache/themes/SuiteP/css/Dawn/style.css
sudo chmod 766 /var/www/html/teste.php
sudo chmod 766 /var/www/html/cache/themes/SuiteP/css/Dawn/style.css